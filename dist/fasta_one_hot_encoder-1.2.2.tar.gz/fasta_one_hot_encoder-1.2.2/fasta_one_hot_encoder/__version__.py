"""Current version of package fasta_one_hot_encoder"""
__version__ = "1.2.2"